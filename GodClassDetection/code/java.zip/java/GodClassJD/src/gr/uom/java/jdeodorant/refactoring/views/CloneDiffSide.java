package gr.uom.java.jdeodorant.refactoring.views;

public enum CloneDiffSide {

	LEFT, RIGHT;
}
