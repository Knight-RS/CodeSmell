package gr.uom.java.ast.visualization;

public interface VisualizationData {
	public int getDistinctSourceDependencies();
	public int getDistinctTargetDependencies();
}
