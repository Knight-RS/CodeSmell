package gr.uom.java.ast.visualization;

public enum ConnectionType {
	
	READ_FIELD_SOURCE, WRITE_FIELD_SOURCE, READ_FIELD_TARGET, WRITE_FIELD_TARGET, METHOD_CALL_SOURCE, METHOD_CALL_TARGET;
}
