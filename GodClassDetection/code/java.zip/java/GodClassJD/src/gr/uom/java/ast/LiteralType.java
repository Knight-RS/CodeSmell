package gr.uom.java.ast;

public enum LiteralType {
	BOOLEAN, CHARACTER, NULL, NUMBER, STRING, TYPE;
}
