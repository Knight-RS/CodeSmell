package gr.uom.java.ast.decomposition.cfg;

public enum PDGDependenceType {
	CONTROL, DATA, ANTI, OUTPUT;
}
