package ca.concordia.jdeodorant.clone.parsers;

public enum CloneInstanceStatus {
	ORIGINAL_LOCATION,
	OFFSETS_SHIFTED,
	TAMPERED
}